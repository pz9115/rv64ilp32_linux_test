#!/bin/sh

export PATH="../bin/:${PATH}"

exec qemu-system-riscv64 -cpu rv64 -M virt -m 1G -nographic -bios fw_dynamic.bin_m64lp64 -kernel Image_rv64ilp32 -drive file=$1,format=raw,id=hd0 -device virtio-blk-device,drive=hd0 -append "rootwait root=/dev/vda ro console=ttyS0 earlycon=sbi"
