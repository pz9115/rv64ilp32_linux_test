#!/bin/sh

export PATH="../bin/:${PATH}"

exec qemu-system-riscv32 -cpu rv32 -M virt -m 1G -nographic -bios fw_dynamic.bin_m32ilp32 -kernel Image_rv32ilp32 -drive file=$1,format=raw,id=hd0 -device virtio-blk-device,drive=hd0 -append "rootwait root=/dev/vda ro console=ttyS0 earlycon=sbi"
